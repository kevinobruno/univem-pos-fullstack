module.exports = {
  arrowParens: 'avoid',
  bracketSameLine: true,
  bracketSpacing: true,
  semi: true,
  singleQuote: true,
  trailingComma: 'all',
};

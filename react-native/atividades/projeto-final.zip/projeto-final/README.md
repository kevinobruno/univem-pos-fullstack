Continuação do tasklist-firebase
Adicionar opção de "check" das tarefas usando o componente de CheckBox do react-native
Quando o checkbox é clicado/desclicado, deve atualizar o firestore (novo campo booleano)
O check deve ser marcado/desmarcado com o que estiver no firestore

.zip anexado no teams ou url de repositório do código

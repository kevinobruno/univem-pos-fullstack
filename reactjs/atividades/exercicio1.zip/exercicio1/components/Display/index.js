import React from 'react';

const Display = ({ value }) => {
  return (
    <>
      <p>{value}</p>
    </>
  );
}

export default Display;

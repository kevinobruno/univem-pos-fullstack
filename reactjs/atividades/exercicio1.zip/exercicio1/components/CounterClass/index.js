import React from 'react';

const CounterClass = () => {
  return (
    <h1 className='Main'>CounterClass</h1>
  );
}

export default CounterClass;

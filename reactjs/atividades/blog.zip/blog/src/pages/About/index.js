import MainContainer from '../../components/MainContainer';

const About = () => {
  return (
    <MainContainer>
      <h1>Sobre</h1>
    </MainContainer>
  );
};

export default About;

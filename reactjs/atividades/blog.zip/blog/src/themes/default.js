const theme = {
  colors: {
    primary: '#2E8BC0',
    primaryDark: '#0C2D48',
    secondary: '#145DA0',
    light: '#f0f0f0',
    dark: '#343a40',
  },
};

export default theme;

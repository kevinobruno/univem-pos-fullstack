import defaultTheme from './default';

export default defaultTheme;

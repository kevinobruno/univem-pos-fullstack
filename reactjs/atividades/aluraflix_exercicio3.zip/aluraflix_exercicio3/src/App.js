import Menu from './components/Menu';

const App = () => {
  return (
    <div>
      <Menu />
    </div>
  );
};

export default App;

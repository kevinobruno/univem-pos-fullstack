class User {
    constructor(student, name, email, country) {
        this.student = student;
        this.name = name;
        this.email = email;
        this.country = country;
    }
}

module.exports = User;

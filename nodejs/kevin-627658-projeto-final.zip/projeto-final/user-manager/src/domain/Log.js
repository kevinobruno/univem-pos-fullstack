class Log {
    constructor(createdAt, method, url) {
        this.createdAt = createdAt;
        this.method = method;
        this.url = url;
    }
}

module.exports = Log;

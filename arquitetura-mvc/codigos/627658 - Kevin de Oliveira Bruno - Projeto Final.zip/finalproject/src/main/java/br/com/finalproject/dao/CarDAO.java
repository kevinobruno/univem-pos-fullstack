package br.com.finalproject.dao;

import br.com.finalproject.domain.Car;

public class CarDAO extends BaseDAO<Car> {}
